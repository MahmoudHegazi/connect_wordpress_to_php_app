


<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "login";
$id = $email = $passowrd = "";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

$the_mail = $the_pass = "";
// if ($_SERVER["REQUEST_METHOD"] == "POST") {
//   $the_mail = $_POST['mail'];
//   $the_pass = $_POST['pass'];
//   if (!empty($the_mail) && !empty($the_pass)) {

//     $sql = 'SELECT email, password FROM users';
//     $result = mysqli_query($conn, $sql);
//     if (mysqli_num_rows($result) > 0) {
//     while ($row = mysqli_fetch_assoc($result)) {
//       if ($row['email'] == $the_mail && $row['password'] == $the_pass) {
//         header("Location: welcome.html");
//         exit();
//       } else {
//         echo "login falied";
//       }
//     }
//   }

//   }

// }

if ($_SERVER["REQUEST_METHOD"] == "GET") {
  $the_mail = $_GET['id'];
  echo $the_mail;
}



?>




<form method="post" action="index.php">

  <input type="text" name="mail"><br>
  <input type="password" name="pass"><br>
  <input type="submit" value="login"><br>
</form>